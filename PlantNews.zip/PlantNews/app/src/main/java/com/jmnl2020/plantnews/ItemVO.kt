package com.jmnl2020.plantnews

class ItemVO constructor(var title:String?, var writer:String?, var date:String?, var url:String?) {
}