package com.jmnl2020.plantnews

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item.view.*
import kotlin.String as String

class MyAdapter constructor(val context: Context, val items: ArrayList<ItemVO>) : RecyclerView.Adapter<RecyclerView.ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        Log.i("test","뷰홀더 생성")
        val layoutInflater:LayoutInflater = LayoutInflater.from(context)
        val itemView:View = layoutInflater.inflate(R.layout.item, parent, false)
        val vh = VH(itemView)

        return  vh
    }

    override fun getItemCount(): Int {
        Log.i("test","아이템 사이즈"+items.size)
        return items.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh: VH = holder as VH //형변환

        val item = items.get(position)

        vh.tvtitle =
        vh.tvwriter
        vh.tvdate
        vh.tvurl


    }

    //ViewHolder 이너클래스 = itemView안의 뷰들을 관리하는 클래스
    inner class VH constructor(itemView: View) : RecyclerView.ViewHolder(itemView){

        var tvtitle = itemView.tv_title
        var tvwriter = itemView.tv_writer
        var tvdate = itemView.tv_date
        var tvurl = itemView.tv_downloadUrl

    }

}